/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>


int main()
{
 int sum=0,avg,i,j,row=3,col=3;
 int matrix[3][3]={{1,2,3},{4,5,6},{7,8,9}};
 for(i=0;i< row;i++)
 {
    for(j=0;j< col;j++)
 
 sum=sum+matrix[i][j];
 avg=sum/9;
 }
 printf("Sum = %d\n", sum);
 printf("Average = %d", avg);
 return 0;
}


