/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>

int main() 
{
    int rollno, m1, m2, m3, total;
    float percentage;
    char name[50], division[10];

    
    printf("Enter roll number: ");
    scanf("%d", &rollno);
    printf("Enter name: ");
    scanf("%s", name);
    printf("Enter marks of three subjects: ");
    scanf("%d %d %d", &m1, &m2, &m3);

    
    total = m1 + m2 + m3;
    percentage = (float)total / 3;

  
    if (percentage >= 60) 
    {
        strcpy(division, "First");
    } else if (percentage >= 50) 
    {
        strcpy(division, "Second");
    } else if (percentage >= 40) 
    {
        strcpy(division, "Third");
    } else {
        strcpy(division, "Fail");
    }

    
    printf("Roll No: %d\n", rollno);
    printf("Name: %s\n", name);
    printf("Total Marks: %d\n", total);
    printf("Percentage: %.2f%%\n", percentage);
    printf("Division: %s\n", division);

    return 0;
}